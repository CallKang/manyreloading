<?php
// XIT was here!

$user_agent = $_SERVER['HTTP_USER_AGENT'];

// List of bot user agent keywords or patterns
$bots = array("bot", "crawler", "spider");

// Loop through the list of bots and check if the user agent contains a keyword or pattern
foreach ($bots as $bot) {
  if (stripos($user_agent, $bot) !== false) {
    // Block the bot by returning a 403 Forbidden response
    header("HTTP/1.0 403 Forbidden");
    exit;
  }
}
?>