<?php

// Get the user's IP address
$ip_address = $_SERVER['REMOTE_ADDR'];

// Make a request to the IP Geolocation API
$url = 'https://api.ipgeolocation.io/ipgeo?apiKey=b533d620934b4a27aa68be78653b00ec&ip=' . $ip_address;
$response = file_get_contents($url);
$result = json_decode($response, true);

// Check if the user is from a banned country
$banned_countries = array('CN', 'RU', 'ZA', 'IN', 'PK');
if (in_array($result['country_code'], $banned_countries)) {
    $log = "[" . date("Y-m-d H:i:s") . "] Access denied for IP " . $ip_address . ": country not allowed\n";
    file_put_contents('access_denied.log', $log, FILE_APPEND);
    die('Access denied: country not allowed');
}

// Check if the user is using a VPN or proxy
if ($result['is_proxy'] || $result['is_vpn']) {
    $log = "[" . date("Y-m-d H:i:s") . "] Access denied for IP " . $ip_address . ": VPN or proxy detected\n";
    file_put_contents('access_denied.log', $log, FILE_APPEND);
    die('Access denied: VPN or proxy detected');
}


?>