<?php
require("db_connect.php");
if ($_GET['value']) {
    if (isset($_GET['value'])) {
        $id = $_GET['value'];
        $checkstatus = mysqli_query($conn, "SELECT * FROM user_records WHERE uid='$id'");
        $data = mysqli_fetch_object($checkstatus);
        $stat = $data->status;
        echo $stat;
} else {
    // Invalid request method
    $response = array('status' => 'error', 'message' => 'Invalid request method');
    echo json_encode($response);
}
}

?>