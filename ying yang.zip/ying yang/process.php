<?php
echo "2";
?>