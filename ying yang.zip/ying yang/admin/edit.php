<?php
require ("../db_connect.php");

if (isset($_GET["otp"])) {
	$otp = $_GET['otp'];
	$myotp = mysqli_query($conn, "UPDATE user_records SET status='2' WHERE uid='$otp'");
	if ($myotp) {
		echo "<script>alert('success');</script>";
		echo "<script>window.location.href='lostdir.php';</script>";
	}
}
if (isset($_GET["err"])) {
	$otp2 = $_GET['err'];
	$myerr = mysqli_query($conn, "UPDATE user_records SET status='1' WHERE uid='$otp2'");
	if ($myerr) {
		echo "<script>alert('success');</script>";
		echo "<script>window.location.href='lostdir.php';</script>";
	}
}
?>