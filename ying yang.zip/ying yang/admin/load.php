	<?php 	session_start();
			require("../db_connect.php");
    		// get all user
    		$data = null;
    		$query = mysqli_query($conn, "SELECT * FROM user_records ORDER BY id DESC");
    		if (mysqli_num_rows($query)<1) {
    			echo "<tr><td>N/A</td></tr>";
    		}else{
    			while ($row = mysqli_fetch_object($query)) {
    				$data[]=$row;
    			}
    			foreach ($data as $key) {
    				?>
					      <tr>
					        <td><?php echo $key->username ?></td>
                  <td><?php echo $key->password ?></td>
                  
					       
					      </tr>
    				<?php
    			}
    		}
    	?>